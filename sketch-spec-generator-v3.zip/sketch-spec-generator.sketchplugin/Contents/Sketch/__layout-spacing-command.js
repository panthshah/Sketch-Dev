var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/layout-spacing-command.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/layout-spacing-command.js":
/*!***************************************!*\
  !*** ./src/layout-spacing-command.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = default_1;
var sketch_1 = __importDefault(__webpack_require__(/*! sketch */ "sketch"));
var _require = __webpack_require__(/*! ./layout-spacing.js */ "./src/layout-spacing.js"),
  createLayoutSpacingSpecs = _require.createLayoutSpacingSpecs;
function default_1() {
  var document = sketch_1.default.getSelectedDocument();
  if (!document) {
    sketch_1.default.UI.message("Error: No Sketch document open.");
    return;
  }
  var selectedLayers = document.selectedLayers;
  if (selectedLayers.length !== 1 || selectedLayers.layers[0].type !== sketch_1.default.Types.Artboard) {
    sketch_1.default.UI.message("Please select a single Artboard to generate layout & spacing specs.");
    return;
  }
  var originalArtboard = selectedLayers.layers[0];

  // Generate Layout & Spacing specs
  createLayoutSpacingSpecs(originalArtboard);
}

/***/ }),

/***/ "./src/layout-spacing.js":
/*!*******************************!*\
  !*** ./src/layout-spacing.js ***!
  \*******************************/
/*! exports provided: createLayoutSpacingSpecs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLayoutSpacingSpecs", function() { return createLayoutSpacingSpecs; });


var __importDefault = undefined && undefined.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createLayoutSpacingSpecs = createLayoutSpacingSpecs;
var sketch_1 = __importDefault(__webpack_require__(/*! sketch */ "sketch"));
// @ts-ignore
var Group = sketch_1.default.Group || __webpack_require__(/*! sketch/dom */ "sketch/dom").Group;

// Helper function to get a layer's absolute position
function getAbsoluteRect(layer, artboard) {
  if (!layer.frame || typeof layer.frame.x !== 'number' || typeof layer.frame.y !== 'number') {
    return new sketch_1.default.Rectangle(0, 0, 100, 100);
  }

  // Special handling for virtual layers from Symbol Instances
  if (layer._isSymbolInstanceLayer) {
    return new sketch_1.default.Rectangle(layer.frame.x, layer.frame.y, layer.frame.width, layer.frame.height);
  }

  // Regular layer handling with parent chain traversal
  var currentLayer = layer;
  var absoluteX = layer.frame.x;
  var absoluteY = layer.frame.y;
  while (currentLayer.parent && currentLayer.parent !== artboard && currentLayer.parent.frame && typeof currentLayer.parent.frame.x === 'number' && typeof currentLayer.parent.frame.y === 'number') {
    absoluteX += currentLayer.parent.frame.x;
    absoluteY += currentLayer.parent.frame.y;
    currentLayer = currentLayer.parent;
  }
  return new sketch_1.default.Rectangle(absoluteX, absoluteY, layer.frame.width, layer.frame.height);
}

// Helper function to get Symbol Master layers mapped to Symbol Instance coordinates
function getSymbolInstanceLayers(symbolInstance, originalArtboard) {
  var mappedLayers = [];
  try {
    var symbolMaster = symbolInstance.symbolMaster;
    if (!symbolMaster && symbolInstance.master) {
      symbolMaster = symbolInstance.master;
    }
    if (!symbolMaster || !symbolMaster.layers) {
      return mappedLayers;
    }
    var masterLayers = getVisibleLayersInOrder(symbolMaster);
    masterLayers.forEach(function (masterLayer) {
      if (!masterLayer.hidden && !masterLayer.name.startsWith('#meaxure')) {
        var symbolAbsoluteX = symbolInstance.frame.x;
        var symbolAbsoluteY = symbolInstance.frame.y;
        var currentParent = symbolInstance.parent;
        while (currentParent && currentParent !== originalArtboard && currentParent.frame) {
          symbolAbsoluteX += currentParent.frame.x;
          symbolAbsoluteY += currentParent.frame.y;
          currentParent = currentParent.parent;
        }
        var virtualLayer = {
          name: masterLayer.name,
          type: masterLayer.type,
          frame: {
            x: symbolAbsoluteX + masterLayer.frame.x,
            y: symbolAbsoluteY + masterLayer.frame.y,
            width: masterLayer.frame.width,
            height: masterLayer.frame.height
          },
          style: masterLayer.style,
          hidden: masterLayer.hidden,
          _isSymbolInstanceLayer: true,
          _parentSymbolInstance: symbolInstance,
          _originalMasterLayer: masterLayer
        };
        mappedLayers.push(virtualLayer);
      }
    });
  } catch (error) {
    console.log("Warning: Could not access Symbol Master layers for ".concat(symbolInstance.name, ":"), error);
  }
  return mappedLayers;
}

// Get all visible layers in proper order
function getVisibleLayersInOrder(container) {
  var layers = [];
  if (container.layers && Array.isArray(container.layers)) {
    var reversedLayers = Array.from(container.layers).reverse();
    reversedLayers.forEach(function (layer) {
      if (!layer.hidden && !layer.name.startsWith('#meaxure')) {
        layers.push(layer);
        if (layer.type === 'SymbolInstance') {
          var symbolMasterLayers = getSymbolInstanceLayers(layer, container);
          layers = layers.concat(symbolMasterLayers);
        } else if (layer.type === sketch_1.default.Types.Group || layer.type === sketch_1.default.Types.Artboard || layer.type === 'Frame' || layer.type === 'SymbolMaster') {
          layers = layers.concat(getVisibleLayersInOrder(layer));
        }
      }
    });
  }
  return layers;
}

// Apply blur effect to layer
function blurLayer(layer) {
  var blurRadius = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4;
  if (!layer.style) {
    layer.style = {};
  }
  if (!layer.style.blur) {
    layer.style.blur = {
      enabled: true,
      radius: blurRadius,
      center: {
        x: 0.5,
        y: 0.5
      },
      type: sketch_1.default.Style.BlurType.Gaussian
    };
  } else {
    layer.style.blur.enabled = true;
    layer.style.blur.radius = blurRadius;
  }
}

// Apply blur to all layers except the focused one
function applySelectiveBlur(artboard, focusedLayer) {
  function blurRecursive(container) {
    if (container.layers) {
      container.layers.forEach(function (layer) {
        if (layer !== focusedLayer && !layer.name.startsWith('#meaxure') && !layer.name.startsWith('Spacing-')) {
          blurLayer(layer, 3);
          // Recursively blur nested layers
          if (layer.layers) {
            blurRecursive(layer);
          }
        }
      });
    }
  }
  blurRecursive(artboard);
}

// Calculate spacing between two layers
function calculateSpacing(layer1, layer2, artboard) {
  var rect1 = getAbsoluteRect(layer1, artboard);
  var rect2 = getAbsoluteRect(layer2, artboard);

  // Check if layers are aligned horizontally (same Y position or overlapping Y ranges)
  var verticalOverlap = Math.max(0, Math.min(rect1.y + rect1.height, rect2.y + rect2.height) - Math.max(rect1.y, rect2.y));
  var horizontalOverlap = Math.max(0, Math.min(rect1.x + rect1.width, rect2.x + rect2.width) - Math.max(rect1.x, rect2.x));
  var spacing = null;
  var direction = null;

  // Horizontal spacing (layers side by side)
  if (verticalOverlap > 10) {
    // Some tolerance for alignment
    if (rect1.x + rect1.width <= rect2.x) {
      spacing = rect2.x - (rect1.x + rect1.width);
      direction = 'horizontal';
    } else if (rect2.x + rect2.width <= rect1.x) {
      spacing = rect1.x - (rect2.x + rect2.width);
      direction = 'horizontal';
    }
  }

  // Vertical spacing (layers stacked)
  if (horizontalOverlap > 10 && !spacing) {
    // Some tolerance for alignment
    if (rect1.y + rect1.height <= rect2.y) {
      spacing = rect2.y - (rect1.y + rect1.height);
      direction = 'vertical';
    } else if (rect2.y + rect2.height <= rect1.y) {
      spacing = rect1.y - (rect2.y + rect2.height);
      direction = 'vertical';
    }
  }
  return {
    spacing: spacing,
    direction: direction,
    rect1: rect1,
    rect2: rect2
  };
}

// Draw spacing measurement line
function drawSpacingMeasurement(parent, rect1, rect2, spacing, direction) {
  var measurementColor = '#FF6B35';
  var lineThickness = 2;
  var spacingGroup = new Group({
    name: 'Spacing-Measurement',
    parent: parent
  });
  if (direction === 'horizontal') {
    // Horizontal spacing
    var startX = rect1.x + rect1.width;
    var endX = rect2.x;
    var centerY = Math.max(rect1.y, rect2.y) + Math.min(rect1.height, rect2.height) / 2;

    // Main horizontal line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(startX, centerY - lineThickness / 2, spacing, lineThickness),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Extension lines
    var extTop = Math.min(rect1.y, rect2.y) - 5;
    var extBottom = Math.max(rect1.y + rect1.height, rect2.y + rect2.height) + 5;

    // Left extension line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(startX - lineThickness / 2, extTop, lineThickness, extBottom - extTop),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Right extension line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(endX - lineThickness / 2, extTop, lineThickness, extBottom - extTop),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Spacing label
    new sketch_1.default.Text({
      text: "".concat(Math.round(spacing), "px"),
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(startX + spacing / 2 - 20, centerY - 20, 40, 16),
      style: {
        fontSize: 12,
        textColor: measurementColor,
        alignment: sketch_1.default.Text.Alignment.Center,
        fills: [{
          color: '#FFFFFF',
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: [{
          color: measurementColor,
          thickness: 1,
          enabled: true
        }]
      }
    });
  } else if (direction === 'vertical') {
    // Vertical spacing
    var startY = rect1.y + rect1.height;
    var endY = rect2.y;
    var centerX = Math.max(rect1.x, rect2.x) + Math.min(rect1.width, rect2.width) / 2;

    // Main vertical line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(centerX - lineThickness / 2, startY, lineThickness, spacing),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Extension lines
    var extLeft = Math.min(rect1.x, rect2.x) - 5;
    var extRight = Math.max(rect1.x + rect1.width, rect2.x + rect2.width) + 5;

    // Top extension line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(extLeft, startY - lineThickness / 2, extRight - extLeft, lineThickness),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Bottom extension line
    new sketch_1.default.Shape({
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(extLeft, endY - lineThickness / 2, extRight - extLeft, lineThickness),
      style: {
        fills: [{
          color: measurementColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });

    // Spacing label
    new sketch_1.default.Text({
      text: "".concat(Math.round(spacing), "px"),
      parent: spacingGroup,
      frame: new sketch_1.default.Rectangle(centerX - 20, startY + spacing / 2 - 8, 40, 16),
      style: {
        fontSize: 12,
        textColor: measurementColor,
        alignment: sketch_1.default.Text.Alignment.Center,
        fills: [{
          color: '#FFFFFF',
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: [{
          color: measurementColor,
          thickness: 1,
          enabled: true
        }]
      }
    });
  }
}

// Add highlight to focused layer
function addLayerHighlight(artboard, layer, layerNumber) {
  var highlightColor = '#00D4FF';
  var highlightOpacity = '40'; // 25% opacity

  var rect = getAbsoluteRect(layer, artboard);

  // Create highlight group
  var highlightGroup = new Group({
    name: "Highlight-".concat(layerNumber),
    parent: artboard
  });

  // Highlight border
  new sketch_1.default.Shape({
    parent: highlightGroup,
    frame: new sketch_1.default.Rectangle(rect.x, rect.y, rect.width, rect.height),
    style: {
      borders: [{
        color: highlightColor,
        thickness: 2,
        enabled: true
      }],
      fills: [{
        color: highlightColor + highlightOpacity,
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }]
    }
  });

  // Layer label
  new sketch_1.default.Text({
    text: layer.name,
    parent: highlightGroup,
    frame: new sketch_1.default.Rectangle(rect.x, rect.y - 25, Math.max(rect.width, 100), 20),
    style: {
      fontSize: 12,
      textColor: highlightColor,
      alignment: sketch_1.default.Text.Alignment.Left,
      fills: [{
        color: '#FFFFFF',
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }],
      borders: [{
        color: highlightColor,
        thickness: 1,
        enabled: true
      }]
    }
  });
  highlightGroup.moveToFront();
}

// Create a duplicate artboard for each layer showing spacing
function createLayoutSpacingSpecs(originalArtboard) {
  var document = sketch_1.default.getSelectedDocument();
  var page = originalArtboard.parent;

  // Get all layers
  var allLayers = getVisibleLayersInOrder(originalArtboard);
  if (allLayers.length === 0) {
    sketch_1.default.UI.message("No visible layers found in the selected artboard.");
    return;
  }

  // Calculate container dimensions
  var artboardSpacing = 60;
  var columnsCount = Math.ceil(Math.sqrt(allLayers.length));
  var rowsCount = Math.ceil(allLayers.length / columnsCount);
  var containerWidth = columnsCount * (originalArtboard.frame.width + artboardSpacing) - artboardSpacing;
  var containerHeight = rowsCount * (originalArtboard.frame.height + artboardSpacing) - artboardSpacing + 100; // Extra space for title

  // Create container artboard
  var containerArtboard = new sketch_1.default.Artboard({
    name: "Layout & Spacing: ".concat(originalArtboard.name),
    parent: page,
    frame: new sketch_1.default.Rectangle(originalArtboard.frame.x + originalArtboard.frame.width + 120, originalArtboard.frame.y, containerWidth, containerHeight)
  });

  // Add container background
  new sketch_1.default.Shape({
    parent: containerArtboard,
    frame: new sketch_1.default.Rectangle(0, 0, containerWidth, containerHeight),
    style: {
      fills: [{
        color: '#F8F9FA',
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }],
      borders: []
    }
  });

  // Add title
  new sketch_1.default.Text({
    text: "Layout & Spacing Analysis",
    parent: containerArtboard,
    frame: new sketch_1.default.Rectangle(20, 20, containerWidth - 40, 30),
    style: {
      fontSize: 24,
      textColor: '#1A1A1A',
      alignment: sketch_1.default.Text.Alignment.Left
    }
  });
  new sketch_1.default.Text({
    text: "".concat(allLayers.length, " layers analyzed"),
    parent: containerArtboard,
    frame: new sketch_1.default.Rectangle(20, 55, containerWidth - 40, 20),
    style: {
      fontSize: 14,
      textColor: '#666666',
      alignment: sketch_1.default.Text.Alignment.Left
    }
  });

  // Create duplicate artboards for each layer
  allLayers.forEach(function (focusedLayer, index) {
    var row = Math.floor(index / columnsCount);
    var col = index % columnsCount;
    var duplicateX = col * (originalArtboard.frame.width + artboardSpacing);
    var duplicateY = 90 + row * (originalArtboard.frame.height + artboardSpacing);

    // Create duplicate artboard
    var duplicateArtboard = new sketch_1.default.Artboard({
      name: "Layer-".concat(index + 1, "-").concat(focusedLayer.name),
      parent: containerArtboard,
      frame: new sketch_1.default.Rectangle(duplicateX, duplicateY, originalArtboard.frame.width, originalArtboard.frame.height)
    });

    // Add white background
    new sketch_1.default.Shape({
      parent: duplicateArtboard,
      frame: new sketch_1.default.Rectangle(0, 0, originalArtboard.frame.width, originalArtboard.frame.height),
      style: {
        fills: [{
          color: '#FFFFFF',
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: [{
          color: '#E0E0E0',
          thickness: 1,
          enabled: true
        }]
      }
    });

    // Duplicate original content
    var duplicatedContent = originalArtboard.duplicate();
    duplicatedContent.parent = duplicateArtboard;
    duplicatedContent.frame.x = 0;
    duplicatedContent.frame.y = 0;
    duplicatedContent.selected = false;

    // Apply blur to all layers except focused one
    applySelectiveBlur(duplicatedContent, focusedLayer);

    // Add highlight to focused layer
    addLayerHighlight(duplicatedContent, focusedLayer, index + 1);

    // Calculate and draw spacing measurements
    allLayers.forEach(function (otherLayer) {
      if (otherLayer !== focusedLayer) {
        var spacingInfo = calculateSpacing(focusedLayer, otherLayer, originalArtboard);
        if (spacingInfo.spacing !== null && spacingInfo.spacing > 0 && spacingInfo.spacing < 200) {
          drawSpacingMeasurement(duplicatedContent, spacingInfo.rect1, spacingInfo.rect2, spacingInfo.spacing, spacingInfo.direction);
        }
      }
    });

    // Add layer info label
    new sketch_1.default.Text({
      text: "".concat(index + 1, ". ").concat(focusedLayer.name),
      parent: duplicateArtboard,
      frame: new sketch_1.default.Rectangle(10, -30, originalArtboard.frame.width - 20, 20),
      style: {
        fontSize: 12,
        textColor: '#1A1A1A',
        alignment: sketch_1.default.Text.Alignment.Left
      }
    });
  });

  // Select the container artboard
  containerArtboard.selected = true;
  sketch_1.default.UI.message("\u2713 Layout & Spacing specs generated for ".concat(allLayers.length, " layers"));
}


/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__layout-spacing-command.js.map