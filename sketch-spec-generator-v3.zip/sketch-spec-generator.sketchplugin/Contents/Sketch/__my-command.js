var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/my-command.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/my-command.js":
/*!***************************!*\
  !*** ./src/my-command.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = default_1;
var sketch_1 = __importDefault(__webpack_require__(/*! sketch */ "sketch"));
// @ts-ignore
var Group = sketch_1.default.Group || __webpack_require__(/*! sketch/dom */ "sketch/dom").Group;
function rgbaToHex(rgba) {
  var r = Math.round(rgba.red * 255).toString(16).padStart(2, '0');
  var g = Math.round(rgba.green * 255).toString(16).padStart(2, '0');
  var b = Math.round(rgba.blue * 255).toString(16).padStart(2, '0');
  var a = Math.round(rgba.alpha * 255).toString(16).padStart(2, '0');
  return "#".concat(r).concat(g).concat(b).concat(a).toUpperCase();
}
// Helper function to get a layer's absolute position using modern Sketch API, safely traversing parent chain
function getAbsoluteRect(layer, artboard) {
  // Safety check for layer frame
  if (!layer.frame || typeof layer.frame.x !== 'number' || typeof layer.frame.y !== 'number') {
    console.log("Warning: Layer ".concat(layer.name, " has invalid frame, using fallback"));
    return new sketch_1.default.Rectangle(0, 0, 100, 100);
  }
  // Special handling for virtual layers from Symbol Instances
  if (layer._isSymbolInstanceLayer) {
    // Virtual layers already have coordinates mapped to the artboard space
    return new sketch_1.default.Rectangle(layer.frame.x, layer.frame.y, layer.frame.width, layer.frame.height);
  }
  // Regular layer handling with parent chain traversal
  var currentLayer = layer;
  var absoluteX = layer.frame.x;
  var absoluteY = layer.frame.y;
  while (currentLayer.parent && currentLayer.parent !== artboard && currentLayer.parent.frame && typeof currentLayer.parent.frame.x === 'number' && typeof currentLayer.parent.frame.y === 'number') {
    absoluteX += currentLayer.parent.frame.x;
    absoluteY += currentLayer.parent.frame.y;
    currentLayer = currentLayer.parent;
  }
  return new sketch_1.default.Rectangle(absoluteX, absoluteY, layer.frame.width, layer.frame.height);
}
// Helper function to draw a simple rectangle representing a layer
function drawLayerRepresentation(parent, x, y, width, height) {
  var fillColor = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : '#D8D8D8';
  new sketch_1.default.Shape({
    parent: parent,
    frame: new sketch_1.default.Rectangle(x, y, width, height),
    style: {
      fills: [{
        color: fillColor,
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }],
      borders: [{
        color: '#979797',
        thickness: 1,
        enabled: true
      }]
    }
  });
}
// Helper function to draw a measurement line using rectangles instead of Path
function drawMeasurement(parent, x1, y1, x2, y2, text) {
  var textOffset = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 10;
  var lineColor = '#666666';
  var lineThickness = 1;
  var lineExtension = 5;
  // Draw the main line using a thin rectangle
  if (x1 === x2) {
    // Vertical line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x1 - lineThickness / 2, y1, lineThickness, y2 - y1),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
  } else if (y1 === y2) {
    // Horizontal line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x1, y1 - lineThickness / 2, x2 - x1, lineThickness),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
  }
  // Draw perpendicular lines at ends using thin rectangles
  if (x1 === x2) {
    // Top perpendicular line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x1 - lineExtension, y1 - lineThickness / 2, lineExtension * 2, lineThickness),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
    // Bottom perpendicular line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x1 - lineExtension, y2 - lineThickness / 2, lineExtension * 2, lineThickness),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
  } else if (y1 === y2) {
    // Left perpendicular line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x1 - lineThickness / 2, y1 - lineExtension, lineThickness, lineExtension * 2),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
    // Right perpendicular line
    new sketch_1.default.Shape({
      parent: parent,
      frame: new sketch_1.default.Rectangle(x2 - lineThickness / 2, y1 - lineExtension, lineThickness, lineExtension * 2),
      style: {
        fills: [{
          color: lineColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
  }
  var textX = Math.min(x1, x2) + Math.abs(x2 - x1) / 2;
  var textY = Math.min(y1, y2) + Math.abs(y2 - y1) / 2;
  if (x1 === x2) {
    textX += textOffset;
  } else if (y1 === y2) {
    textY -= textOffset;
  }
  new sketch_1.default.Text({
    text: text,
    parent: parent,
    frame: new sketch_1.default.Rectangle(textX - 20, textY - 10, 40, 20),
    style: {
      textColor: lineColor,
      fontSize: 10,
      alignment: sketch_1.default.Text.Alignment.Center
    }
  });
}
function duplicateArtboard(originalArtboard, suffix) {
  var page = originalArtboard.parent;
  var newArtboard = originalArtboard.duplicate();
  newArtboard.name = "Specs: ".concat(originalArtboard.name, " - ").concat(suffix);
  newArtboard.parent = page;
  // Unlock all child layers for annotation
  newArtboard.layers.forEach(function (layer) {
    layer.locked = false;
  });
  return newArtboard;
}
function createSpecsGroup(artboard, groupName) {
  var group = new Group({
    name: groupName,
    parent: artboard,
    frame: new sketch_1.default.Rectangle(0, 0, artboard.frame.width, artboard.frame.height)
  });
  return group;
}
function getAllLayers(layerContainer) {
  var layers = [];
  if (layerContainer.layers) {
    layerContainer.layers.forEach(function (layer) {
      if (!layer.name.startsWith('#meaxure')) {
        layers.push(layer);
        if (layer.type === sketch_1.default.Types.Group || layer.type === sketch_1.default.Types.Artboard || layer.type === 'SymbolMaster' || layer.type === 'SymbolInstance') {
          layers = layers.concat(getAllLayers(layer));
        }
      }
    });
  }
  return layers;
}
function drawLayoutSpecs(artboard, specsGroup) {
  // For each layer, draw dimension lines and spacing callouts, offset from the design
  var layers = getAllLayers(artboard);
  var offset = 32; // px offset for callouts
  var colorBox = '#1E90FF';
  var colorText = '#1E90FF';
  // Draw bounding boxes and dimension labels
  layers.forEach(function (layer, idx) {
    console.log("Annotating layer: ".concat(layer.name, " (").concat(layer.type, ")"));
    var rect = getAbsoluteRect(layer, artboard);
    // Bounding box
    new sketch_1.default.Shape({
      parent: specsGroup,
      frame: new sketch_1.default.Rectangle(rect.x, rect.y, rect.width, rect.height),
      style: {
        borders: [{
          color: colorBox,
          thickness: 2,
          enabled: true
        }],
        fills: []
      }
    });
    // Width label (above)
    new sketch_1.default.Text({
      text: "".concat(Math.round(rect.width), "px"),
      parent: specsGroup,
      frame: new sketch_1.default.Rectangle(rect.x + rect.width / 2 - 24, rect.y - offset, 48, 18),
      style: {
        fontSize: 13,
        textColor: colorText,
        alignment: sketch_1.default.Text.Alignment.Center
      }
    });
    // Height label (right)
    new sketch_1.default.Text({
      text: "".concat(Math.round(rect.height), "px"),
      parent: specsGroup,
      frame: new sketch_1.default.Rectangle(rect.x + rect.width + 8, rect.y + rect.height / 2 - 9, 48, 18),
      style: {
        fontSize: 13,
        textColor: colorText,
        alignment: sketch_1.default.Text.Alignment.Center
      }
    });
    // Spacing to next layer (if not last)
    if (idx < layers.length - 1) {
      var nextRect = getAbsoluteRect(layers[idx + 1], artboard);
      // Horizontal spacing (if aligned vertically)
      if (rect.y === nextRect.y && rect.height === nextRect.height) {
        var spacing = nextRect.x - (rect.x + rect.width);
        if (spacing > 0) {
          // Draw line
          new sketch_1.default.Shape({
            parent: specsGroup,
            frame: new sketch_1.default.Rectangle(rect.x + rect.width, rect.y + rect.height / 2 - 1, spacing, 2),
            style: {
              fills: [{
                color: colorBox,
                fillType: sketch_1.default.Style.FillType.Color,
                enabled: true
              }],
              borders: []
            }
          });
          // Label
          new sketch_1.default.Text({
            text: "".concat(spacing, "px"),
            parent: specsGroup,
            frame: new sketch_1.default.Rectangle(rect.x + rect.width + spacing / 2 - 16, rect.y + rect.height / 2 - 12, 32, 16),
            style: {
              fontSize: 12,
              textColor: colorText,
              alignment: sketch_1.default.Text.Alignment.Center
            }
          });
        }
      }
      // Vertical spacing (if aligned horizontally)
      if (rect.x === nextRect.x && rect.width === nextRect.width) {
        var _spacing = nextRect.y - (rect.y + rect.height);
        if (_spacing > 0) {
          // Draw line
          new sketch_1.default.Shape({
            parent: specsGroup,
            frame: new sketch_1.default.Rectangle(rect.x + rect.width / 2 - 1, rect.y + rect.height, 2, _spacing),
            style: {
              fills: [{
                color: colorBox,
                fillType: sketch_1.default.Style.FillType.Color,
                enabled: true
              }],
              borders: []
            }
          });
          // Label
          new sketch_1.default.Text({
            text: "".concat(_spacing, "px"),
            parent: specsGroup,
            frame: new sketch_1.default.Rectangle(rect.x + rect.width / 2 - 16, rect.y + rect.height + _spacing / 2 - 8, 32, 16),
            style: {
              fontSize: 12,
              textColor: colorText,
              alignment: sketch_1.default.Text.Alignment.Center
            }
          });
        }
      }
    }
  });
}
// Helper: Recursively build a tree of all layers, with type and children
function buildLayerTree(layer) {
  var depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var parentIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var result = [];
  // Detect type
  var type = layer.type;
  var isStack = false;
  var isFrame = false;
  var isSymbol = false;
  var isGroup = false;
  var isGraphic = false;
  // Try to detect modern types (Frame, Stack, Symbol, Graphic)
  if (type === 'Artboard' || type === 'Frame') {
    isFrame = true;
    // Stacks are Frames with layout properties
    if (layer.layout && (layer.layout.direction || layer.layout.spacing !== undefined)) {
      isStack = true;
    }
  } else if (type === 'Group') {
    isGroup = true;
    // Stacks can also be Groups with layout
    if (layer.layout && (layer.layout.direction || layer.layout.spacing !== undefined)) {
      isStack = true;
    }
  } else if (type === 'SymbolInstance' || type === 'SymbolMaster') {
    isSymbol = true;
  } else if (type === 'Graphic') {
    isGraphic = true;
  }
  // Compose node
  var node = {
    layer: layer,
    type: type,
    isStack: isStack,
    isFrame: isFrame,
    isSymbol: isSymbol,
    isGroup: isGroup,
    isGraphic: isGraphic,
    depth: depth,
    parentIndex: parentIndex,
    children: []
  };
  // Recursively add children
  if (layer.layers && Array.isArray(layer.layers) && layer.layers.length > 0) {
    node.children = layer.layers.map(function (child, i) {
      return buildLayerTree(child, depth + 1, parentIndex + (parentIndex ? '.' : '') + (i + 1));
    }).flat();
  }
  result.push(node);
  if (node.children.length > 0) {
    result = result.concat(node.children);
  }
  return result;
}
function default_1() {
  var document = sketch_1.default.getSelectedDocument();
  if (!document) {
    sketch_1.default.UI.message("Error: No Sketch document open.");
    return;
  }
  var selectedLayers = document.selectedLayers;
  if (selectedLayers.length !== 1 || selectedLayers.layers[0].type !== sketch_1.default.Types.Artboard) {
    sketch_1.default.UI.message("Please select a single Artboard to generate specs.");
    return;
  }
  var originalArtboard = selectedLayers.layers[0];
  var page = originalArtboard.parent;
  // --- Visual Design Constants ---
  var highlightColor = '#00D4FF'; // Cyan color for highlights
  var highlightOpacity = '66'; // 40% opacity in hex (66 = 102/255)
  var numberBgColor = '#FF3366'; // Vibrant red for number badges
  var panelBgColor = '#FFFFFF';
  var panelBorderColor = '#E0E0E0';
  var textPrimaryColor = '#1A1A1A';
  var textSecondaryColor = '#666666';
  // --- Layout Constants ---
  var artboardSpacing = 120;
  var panelWidth = 420;
  var panelPadding = 32;
  var panelItemSpacing = 24;
  var numberBadgeSize = 32;
  var minHighlightSize = 20; // Minimum size for small elements
  // --- Get all visible layers in layer panel order ---
  function getVisibleLayersInOrder(container) {
    var layers = [];
    // Process layers from top to bottom (as they appear in layers panel)
    if (container.layers && Array.isArray(container.layers)) {
      // Sketch layers are in reverse order (bottom layer is index 0)
      // So we need to reverse to get top-to-bottom order
      var reversedLayers = Array.from(container.layers).reverse();
      reversedLayers.forEach(function (layer) {
        // Skip hidden layers and meaxure annotations
        if (!layer.hidden && !layer.name.startsWith('#meaxure')) {
          layers.push(layer);
          // Special handling for Symbol Instances - get their master's layers
          if (layer.type === 'SymbolInstance') {
            var symbolMasterLayers = getSymbolInstanceLayers(layer);
            layers = layers.concat(symbolMasterLayers);
          }
          // Recursively get nested layers for other types
          else if (layer.type === sketch_1.default.Types.Group || layer.type === sketch_1.default.Types.Artboard || layer.type === 'Frame' || layer.type === 'SymbolMaster') {
            layers = layers.concat(getVisibleLayersInOrder(layer));
          }
        }
      });
    }
    return layers;
  }
  // Helper function to get Symbol Master layers mapped to Symbol Instance coordinates
  function getSymbolInstanceLayers(symbolInstance) {
    var mappedLayers = [];
    try {
      // Get the Symbol Master from the instance - try multiple approaches
      var symbolMaster = symbolInstance.symbolMaster;
      // If symbolMaster doesn't exist, try the 'master' property
      if (!symbolMaster && symbolInstance.master) {
        symbolMaster = symbolInstance.master;
      }
      if (!symbolMaster) {
        return mappedLayers;
      }
      if (!symbolMaster.layers) {
        return mappedLayers;
      }
      // Get all layers from the Symbol Master
      var masterLayers = getVisibleLayersInOrder(symbolMaster);
      // Map each master layer to the instance's coordinate space
      masterLayers.forEach(function (masterLayer, index) {
        if (!masterLayer.hidden && !masterLayer.name.startsWith('#meaxure')) {
          // Create a virtual layer that represents this master layer in the instance
          // Calculate absolute position by traversing the symbol instance's parent chain
          var symbolAbsoluteX = symbolInstance.frame.x;
          var symbolAbsoluteY = symbolInstance.frame.y;
          // Traverse parent chain to get absolute coordinates
          var currentParent = symbolInstance.parent;
          while (currentParent && currentParent !== originalArtboard && currentParent.frame) {
            symbolAbsoluteX += currentParent.frame.x;
            symbolAbsoluteY += currentParent.frame.y;
            currentParent = currentParent.parent;
          }
          // Only copy essential properties to avoid issues with Sketch objects
          var virtualLayer = {
            name: masterLayer.name,
            type: masterLayer.type,
            frame: {
              x: symbolAbsoluteX + masterLayer.frame.x,
              y: symbolAbsoluteY + masterLayer.frame.y,
              width: masterLayer.frame.width,
              height: masterLayer.frame.height
            },
            style: masterLayer.style,
            hidden: masterLayer.hidden,
            // Mark it as a virtual layer from a symbol for identification
            _isSymbolInstanceLayer: true,
            _parentSymbolInstance: symbolInstance,
            _originalMasterLayer: masterLayer
          };
          mappedLayers.push(virtualLayer);
        }
      });
    } catch (error) {
      console.log("Warning: Could not access Symbol Master layers for ".concat(symbolInstance.name, ":"), error);
    }
    return mappedLayers;
  }
  // Get all layers in proper order
  var orderedLayers = getVisibleLayersInOrder(originalArtboard);
  if (orderedLayers.length === 0) {
    sketch_1.default.UI.message("No visible layers found in the selected artboard.");
    return;
  }
  // --- Calculate dimensions ---
  var anatomyArtboardWidth = originalArtboard.frame.width + panelWidth + artboardSpacing;
  var panelItemHeight = 160; // Height for each spec item (increased for more specs)
  var panelHeaderHeight = 120;
  var panelContentHeight = orderedLayers.length * panelItemHeight + (orderedLayers.length - 1) * panelItemSpacing;
  var panelTotalHeight = panelHeaderHeight + panelContentHeight + panelPadding * 2;
  var anatomyArtboardHeight = Math.max(originalArtboard.frame.height, panelTotalHeight);
  // --- Create the Anatomy Artboard ---
  var anatomyArtboard = new sketch_1.default.Artboard({
    name: "Anatomy: ".concat(originalArtboard.name),
    parent: page,
    frame: new sketch_1.default.Rectangle(originalArtboard.frame.x + originalArtboard.frame.width + artboardSpacing, originalArtboard.frame.y, anatomyArtboardWidth, anatomyArtboardHeight)
  });
  // --- Add white background ---
  new sketch_1.default.Shape({
    parent: anatomyArtboard,
    frame: new sketch_1.default.Rectangle(0, 0, anatomyArtboardWidth, anatomyArtboardHeight),
    style: {
      fills: [{
        color: '#FFFFFF',
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }],
      borders: []
    }
  });
  // --- Duplicate original artboard content ---
  var duplicatedContent = originalArtboard.duplicate();
  duplicatedContent.parent = anatomyArtboard;
  duplicatedContent.frame.x = 0;
  duplicatedContent.frame.y = 0;
  duplicatedContent.selected = false;
  // --- Create Specifications Panel ---
  var panelX = originalArtboard.frame.width + artboardSpacing / 2;
  // Panel background
  new sketch_1.default.Shape({
    parent: anatomyArtboard,
    frame: new sketch_1.default.Rectangle(panelX, 0, panelWidth, anatomyArtboardHeight),
    style: {
      fills: [{
        color: panelBgColor,
        fillType: sketch_1.default.Style.FillType.Color,
        enabled: true
      }],
      borders: [{
        color: panelBorderColor,
        thickness: 1,
        enabled: true
      }]
    }
  });
  // Panel header
  new sketch_1.default.Text({
    text: 'Layer Specifications',
    parent: anatomyArtboard,
    frame: new sketch_1.default.Rectangle(panelX + panelPadding, panelPadding, panelWidth - panelPadding * 2, 40),
    style: {
      fontSize: 28,
      textColor: textPrimaryColor,
      alignment: 'left'
    }
  });
  // Subtitle
  new sketch_1.default.Text({
    text: "".concat(orderedLayers.length, " layers identified"),
    parent: anatomyArtboard,
    frame: new sketch_1.default.Rectangle(panelX + panelPadding, panelPadding + 48, panelWidth - panelPadding * 2, 24),
    style: {
      fontSize: 16,
      textColor: textSecondaryColor,
      alignment: 'left'
    }
  });
  // --- Create highlights and panel entries for each layer ---
  var panelY = panelHeaderHeight;
  orderedLayers.forEach(function (layer, index) {
    var _layer$style2;
    var layerNumber = index + 1;
    var rect = getAbsoluteRect(layer, originalArtboard);
    // --- Create highlight overlay ---
    var highlightGroup = new Group({
      name: "Highlight-".concat(layerNumber),
      parent: anatomyArtboard
    });
    // Calculate position relative to the duplicated content (which starts at 0,0)
    // Both regular and virtual layers return absolute coordinates from getAbsoluteRect
    // So we always subtract the original artboard position to get relative coordinates
    var relativeX = rect.x - originalArtboard.frame.x;
    var relativeY = rect.y - originalArtboard.frame.y;
    // Ensure minimum size for tiny elements
    var highlightWidth = Math.max(rect.width, minHighlightSize);
    var highlightHeight = Math.max(rect.height, minHighlightSize);
    var highlightX = relativeX;
    var highlightY = relativeY;
    // Center small highlights on the original element
    if (rect.width < minHighlightSize) {
      highlightX = relativeX - (minHighlightSize - rect.width) / 2;
    }
    if (rect.height < minHighlightSize) {
      highlightY = relativeY - (minHighlightSize - rect.height) / 2;
    }
    // Highlight rectangle
    var highlight = new sketch_1.default.Shape({
      parent: highlightGroup,
      frame: new sketch_1.default.Rectangle(highlightX, highlightY, highlightWidth, highlightHeight),
      style: {
        borders: [{
          color: highlightColor,
          thickness: 2,
          enabled: true
        }],
        fills: [{
          color: highlightColor + highlightOpacity,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }]
      }
    });
    // Number badge positioned at top-left of highlight
    var badgeX = highlightX + 8;
    var badgeY = highlightY; // Align to top edge for consistency
    // Badge background
    new sketch_1.default.Shape({
      parent: highlightGroup,
      frame: new sketch_1.default.Rectangle(badgeX, badgeY, numberBadgeSize, numberBadgeSize),
      style: {
        fills: [{
          color: numberBgColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: [{
          color: '#FFFFFF',
          thickness: 2,
          enabled: true
        }]
      }
    });
    // Badge number
    new sketch_1.default.Text({
      text: "".concat(layerNumber),
      parent: highlightGroup,
      frame: new sketch_1.default.Rectangle(badgeX, badgeY, numberBadgeSize, numberBadgeSize),
      style: {
        fontSize: 16,
        textColor: '#FFFFFF',
        alignment: 'center'
      }
    });
    // Move highlight group to front and ensure it's visible
    highlightGroup.moveToFront();
    highlightGroup.locked = false;
    highlightGroup.hidden = false;
    // --- Create panel entry ---
    var entryY = panelY + index * (panelItemHeight + panelItemSpacing);
    // Entry background (subtle hover effect simulation)
    new sketch_1.default.Shape({
      parent: anatomyArtboard,
      frame: new sketch_1.default.Rectangle(panelX + panelPadding, entryY, panelWidth - panelPadding * 2, panelItemHeight),
      style: {
        fills: [{
          color: '#FAFAFA',
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: [{
          color: '#EEEEEE',
          thickness: 1,
          enabled: true
        }]
      }
    });
    // Entry number badge
    new sketch_1.default.Shape({
      parent: anatomyArtboard,
      frame: new sketch_1.default.Rectangle(panelX + panelPadding + 12, entryY + (panelItemHeight - numberBadgeSize) / 2, numberBadgeSize, numberBadgeSize),
      style: {
        fills: [{
          color: numberBgColor,
          fillType: sketch_1.default.Style.FillType.Color,
          enabled: true
        }],
        borders: []
      }
    });
    new sketch_1.default.Text({
      text: "".concat(layerNumber),
      parent: anatomyArtboard,
      frame: new sketch_1.default.Rectangle(panelX + panelPadding + 12, entryY + (panelItemHeight - numberBadgeSize) / 2, numberBadgeSize, numberBadgeSize),
      style: {
        fontSize: 14,
        textColor: '#FFFFFF',
        alignment: 'center'
      }
    });
    // Layer name
    new sketch_1.default.Text({
      text: layer.name,
      parent: anatomyArtboard,
      frame: new sketch_1.default.Rectangle(panelX + panelPadding + 60, entryY + 8, panelWidth - panelPadding * 2 - 72, 20),
      style: {
        fontSize: 16,
        textColor: textPrimaryColor,
        alignment: 'left'
      }
    });
    // Layer type and dimensions
    var typeLabel = layer.type.replace('MSLayer', '').replace('Group', 'Group');
    if (layer.type === 'SymbolInstance') {
      typeLabel = 'Symbol Instance';
    } else if (layer.type === 'SymbolMaster') {
      typeLabel = 'Symbol Master';
    } else if (layer._isSymbolInstanceLayer) {
      // This is a virtual layer from a Symbol Instance
      var originalType = layer._originalMasterLayer.type.replace('MSLayer', '').replace('Group', 'Group');
      typeLabel = "".concat(originalType, " (in Symbol)");
    }
    var dimensions = "".concat(Math.round(rect.width), " \xD7 ").concat(Math.round(rect.height));
    new sketch_1.default.Text({
      text: "".concat(typeLabel, " \u2022 ").concat(dimensions),
      parent: anatomyArtboard,
      frame: new sketch_1.default.Rectangle(panelX + panelPadding + 60, entryY + 28, panelWidth - panelPadding * 2 - 72, 16),
      style: {
        fontSize: 12,
        textColor: textSecondaryColor,
        alignment: 'left'
      }
    });
    // Extract detailed specifications
    var style = layer.style || {};
    var fills = style.fills || [];
    var borders = style.borders || [];
    var shadows = style.shadows || [];
    // Background Color
    var backgroundColor = fills.length && fills[0].enabled ? typeof fills[0].color === 'string' ? fills[0].color : rgbaToHex(fills[0].color) : 'None';
    // Border properties
    var borderColor = borders.length && borders[0].enabled ? typeof borders[0].color === 'string' ? borders[0].color : rgbaToHex(borders[0].color) : 'None';
    var borderWidth = borders.length && borders[0].enabled ? "".concat(borders[0].thickness, "px") : 'None';
    // Corner radius - check multiple possible properties including smart layout frames
    var borderRadius = '0px';
    // Try Sketch object corner radius first (most reliable from logs)
    if (layer.sketchObject && layer.sketchObject.cornerRadius) {
      try {
        var radius = layer.sketchObject.cornerRadius();
        if (radius > 0) {
          borderRadius = "".concat(radius, "px");
        }
      } catch (e) {
        // Corner radius method doesn't exist or failed
      }
    }
    // If no radius found yet, try other methods
    if (borderRadius === '0px') {
      var _layer$style;
      if (style.borderRadius !== undefined && style.borderRadius > 0) {
        borderRadius = "".concat(style.borderRadius, "px");
      } else if (((_layer$style = layer.style) === null || _layer$style === void 0 ? void 0 : _layer$style.borderRadius) !== undefined && layer.style.borderRadius > 0) {
        borderRadius = "".concat(layer.style.borderRadius, "px");
      } else if (layer.cornerRadius !== undefined && layer.cornerRadius > 0) {
        borderRadius = "".concat(layer.cornerRadius, "px");
      } else if (layer.fixedRadius !== undefined && layer.fixedRadius > 0) {
        borderRadius = "".concat(layer.fixedRadius, "px");
      } else if (layer.points && layer.points.length > 0 && layer.points[0].cornerRadius !== undefined && layer.points[0].cornerRadius > 0) {
        borderRadius = "".concat(layer.points[0].cornerRadius, "px");
      }
    }
    // For Smart Layout stacks (MSLayerGroup), try additional methods
    if (borderRadius === '0px' && layer.sketchObject && layer.sketchObject.className() === 'MSLayerGroup') {
      try {
        // Check if it's a smart layout with background layer
        if (layer.sketchObject.hasBackgroundColor && layer.sketchObject.hasBackgroundColor()) {
          // Smart layouts might store radius in style
          var _style = layer.sketchObject.style();
          if (_style && _style.contextSettings && _style.contextSettings()) {
            var contextSettings = _style.contextSettings();
            if (contextSettings.borderRadius) {
              var _radius = contextSettings.borderRadius();
              if (_radius > 0) {
                borderRadius = "".concat(_radius, "px");
              }
            }
          }
        }
        // Check background layers for radius
        if (layer.sketchObject.layers && layer.sketchObject.layers()) {
          var layers = layer.sketchObject.layers();
          for (var i = 0; i < layers.count(); i++) {
            var childLayer = layers.objectAtIndex(i);
            if (childLayer.cornerRadius && childLayer.cornerRadius() > 0) {
              borderRadius = "".concat(childLayer.cornerRadius(), "px");
              break;
            }
          }
        }
      } catch (e) {
        // Smart layout radius detection failed
      }
    }
    // Opacity
    var opacity = ((_layer$style2 = layer.style) === null || _layer$style2 === void 0 ? void 0 : _layer$style2.opacity) !== undefined ? "".concat(Math.round(layer.style.opacity * 100), "%") : '100%';
    // Shadow
    var shadowInfo = shadows.length && shadows[0].enabled ? "".concat(shadows[0].x, "px ").concat(shadows[0].y, "px ").concat(shadows[0].blur, "px ").concat(shadows[0].color || '#000') : 'None';
    var specY = entryY + 48;
    var specLineHeight = 14;
    // Create specification lines
    function addSpecLine(label, value, yOffset) {
      new sketch_1.default.Text({
        text: "".concat(label, ": ").concat(value),
        parent: anatomyArtboard,
        frame: new sketch_1.default.Rectangle(panelX + panelPadding + 60, specY + yOffset, panelWidth - panelPadding * 2 - 72, 12),
        style: {
          fontSize: 10,
          textColor: textSecondaryColor,
          alignment: 'left'
        }
      });
    }
    // Add specifications based on layer type
    if (layer.type === sketch_1.default.Types.Text || layer._isSymbolInstanceLayer && layer._originalMasterLayer.type === sketch_1.default.Types.Text) {
      // Text-specific properties
      var textStyle = layer.style || {};
      var fontFamily = textStyle.fontFamily || layer.fontFamily || 'Unknown';
      var fontSize = textStyle.fontSize || layer.fontSize || 'Unknown';
      // Get actual font style name (e.g. "Bold", "Medium Italic", "Light")
      var fontWeight = 'Regular';
      // First try to get the actual font style name from Sketch object (most reliable)
      if (layer.sketchObject && layer.sketchObject.font && layer.sketchObject.font()) {
        var font = layer.sketchObject.font();
        if (font.displayName && font.displayName()) {
          // Extract style from display name (e.g., "SF Pro Medium Italic" -> "Medium Italic")
          var displayName = font.displayName();
          var familyName = font.familyName ? font.familyName() : '';
          if (familyName && displayName.startsWith(familyName)) {
            fontWeight = displayName.substring(familyName.length).trim();
            if (!fontWeight) fontWeight = 'Regular';
          } else {
            fontWeight = displayName;
          }
        } else if (font.fontName && font.fontName()) {
          // Extract style from font name (e.g., "SFPro-MediumItalic" -> "MediumItalic")
          var fontName = font.fontName();
          var parts = fontName.split('-');
          if (parts.length > 1) {
            fontWeight = parts[parts.length - 1];
          }
        }
      }
      // Fallback to numeric weight if no style name found
      if (fontWeight === 'Regular') {
        var numericWeight = undefined;
        if (textStyle.fontWeight !== undefined) {
          numericWeight = textStyle.fontWeight;
        } else if (layer.fontWeight !== undefined) {
          numericWeight = layer.fontWeight;
        } else if (layer.font && layer.font.fontWeight !== undefined) {
          numericWeight = layer.font.fontWeight;
        }
        if (numericWeight !== undefined) {
          if (typeof numericWeight === 'number') {
            var weightMap = {
              100: 'Thin',
              200: 'ExtraLight',
              300: 'Light',
              400: 'Regular',
              500: 'Medium',
              600: 'SemiBold',
              700: 'Bold',
              800: 'ExtraBold',
              900: 'Black'
            };
            fontWeight = weightMap[numericWeight] || "".concat(numericWeight);
          } else {
            fontWeight = "".concat(numericWeight);
          }
        }
      }
      var textColor = textStyle.textColor ? typeof textStyle.textColor === 'string' ? textStyle.textColor : rgbaToHex(textStyle.textColor) : textPrimaryColor;
      var lineHeight = textStyle.lineHeight || layer.lineHeight || 'Auto';
      var textAlign = textStyle.alignment || layer.alignment || 'Left';
      addSpecLine('Font', "".concat(fontFamily), 0);
      addSpecLine('Weight', "".concat(fontWeight), specLineHeight);
      addSpecLine('Size', "".concat(fontSize, "px"), specLineHeight * 2);
      addSpecLine('Color', textColor, specLineHeight * 3);
      addSpecLine('Line Height', "".concat(lineHeight), specLineHeight * 4);
      addSpecLine('Align', textAlign, specLineHeight * 5);
      if (opacity !== '100%') addSpecLine('Opacity', opacity, specLineHeight * 6);
    } else if (layer._isSymbolInstanceLayer) {
      // Virtual layer from Symbol Instance - show original layer info + symbol context
      var originalLayer = layer._originalMasterLayer;
      var parentSymbol = layer._parentSymbolInstance;
      addSpecLine('Source', "".concat(originalLayer.type, " in Symbol"), 0);
      addSpecLine('Symbol', parentSymbol.name, specLineHeight);
      addSpecLine('Layer Name', originalLayer.name, specLineHeight * 2);
      // Show standard layer properties
      if (backgroundColor !== 'None') {
        addSpecLine('Background', backgroundColor, specLineHeight * 3);
      }
      if (borderColor !== 'None') {
        addSpecLine('Border', "".concat(borderWidth, " ").concat(borderColor), specLineHeight * 4);
        addSpecLine('Radius', borderRadius, specLineHeight * 5);
      } else if (borderRadius !== '0px') {
        addSpecLine('Radius', borderRadius, specLineHeight * 4);
      }
      if (opacity !== '100%') addSpecLine('Opacity', opacity, specLineHeight * 6);
    } else if (layer.type === 'SymbolInstance' || layer.type === 'SymbolMaster') {
      // Symbol-specific properties
      var symbolType = layer.type === 'SymbolInstance' ? 'Instance' : 'Master';
      addSpecLine('Type', symbolType, 0);
      // For Symbol Instances, show master information
      if (layer.type === 'SymbolInstance') {
        var masterName = layer.symbolMaster ? layer.symbolMaster.name : 'Unknown';
        var symbolId = layer.symbolId || 'Unknown';
        addSpecLine('Master', masterName, specLineHeight);
        addSpecLine('Symbol ID', symbolId, specLineHeight * 2);
        // Check for overrides
        var overrideCount = 0;
        if (layer.overrides && Array.isArray(layer.overrides)) {
          overrideCount = layer.overrides.filter(function (override) {
            return !override.isDefault;
          }).length;
        }
        addSpecLine('Overrides', "".concat(overrideCount, " active"), specLineHeight * 3);
        if (opacity !== '100%') addSpecLine('Opacity', opacity, specLineHeight * 4);
      } else {
        // For Symbol Masters, show usage information
        addSpecLine('Master Name', layer.name, specLineHeight);
        // Symbol Master properties
        var masterSymbolId = layer.symbolId || 'Unknown';
        addSpecLine('Symbol ID', masterSymbolId, specLineHeight * 2);
        if (opacity !== '100%') addSpecLine('Opacity', opacity, specLineHeight * 3);
      }
    } else {
      // Shape/Group properties
      addSpecLine('Background', backgroundColor, 0);
      if (borderColor !== 'None') {
        addSpecLine('Border', "".concat(borderWidth, " ").concat(borderColor), specLineHeight);
        addSpecLine('Radius', borderRadius, specLineHeight * 2);
      } else {
        addSpecLine('Radius', borderRadius, specLineHeight);
      }
      if (opacity !== '100%') addSpecLine('Opacity', opacity, specLineHeight * (borderColor !== 'None' ? 3 : 2));
      if (shadowInfo !== 'None') addSpecLine('Shadow', shadowInfo, specLineHeight * (borderColor !== 'None' ? 4 : 3));
    }
  });
  // Clean up any temporary data
  if (globalThis._badgePositions) {
    delete globalThis._badgePositions;
  }
  // Select the new anatomy artboard
  anatomyArtboard.selected = true;
  sketch_1.default.UI.message("\u2713 Anatomy specs generated for ".concat(orderedLayers.length, " layers"));
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__my-command.js.map