var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/layout-spacing-command.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/layout-spacing-command.js":
/*!***************************************!*\
  !*** ./src/layout-spacing-command.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = default_1;
var sketch = __webpack_require__(/*! sketch */ "sketch");
var _require = __webpack_require__(/*! ./layout-spacing.js */ "./src/layout-spacing.js"),
  createLayoutSpacingSpecs = _require.createLayoutSpacingSpecs;
function default_1() {
  var document = sketch.getSelectedDocument();
  if (!document) {
    sketch.UI.message("Error: No Sketch document open.");
    return;
  }
  var selectedLayers = document.selectedLayers;
  if (selectedLayers.length === 0) {
    sketch.UI.message("Please select a layer to generate spacing measurements.");
    return;
  }
  if (selectedLayers.length > 1) {
    sketch.UI.message("Please select only one layer at a time for spacing analysis.");
    return;
  }
  var selectedLayer = selectedLayers.layers[0];

  // Find the artboard containing this layer
  var artboard = selectedLayer;
  while (artboard && artboard.type !== sketch.Types.Artboard) {
    artboard = artboard.parent;
  }
  if (!artboard) {
    sketch.UI.message("Selected layer must be inside an artboard.");
    return;
  }

  // Generate spacing specs for the selected layer
  createLayoutSpacingSpecs(artboard, selectedLayer);
}
module.exports = {
  default: default_1
};

/***/ }),

/***/ "./src/layout-spacing.js":
/*!*******************************!*\
  !*** ./src/layout-spacing.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var sketch = __webpack_require__(/*! sketch */ "sketch");

// Get absolute position of a layer within an artboard (FIXED coordinates)
function getAbsoluteRect(layer, artboard) {
  if (!layer.frame || typeof layer.frame.x !== 'number' || typeof layer.frame.y !== 'number') {
    // Keep this warning as it's useful for error diagnosis
    console.log("Warning: Layer ".concat(layer.name, " has invalid frame, using fallback"));
    return new sketch.Rectangle(0, 0, 100, 100);
  }

  // For artboard itself, use its frame directly but relative to (0,0)
  if (layer === artboard) {
    return new sketch.Rectangle(0, 0, artboard.frame.width, artboard.frame.height);
  }

  // Use the layer's frame directly - it should already be relative to the artboard
  return new sketch.Rectangle(layer.frame.x, layer.frame.y, layer.frame.width, layer.frame.height);
}

// Get visible layers in order
function getVisibleLayersInOrder(container) {
  var layers = [];
  if (container.layers && Array.isArray(container.layers)) {
    container.layers.forEach(function (layer) {
      if (!layer.hidden && !layer.name.startsWith('#meaxure')) {
        layers.push(layer);
        if (layer.type === sketch.Types.Group || layer.type === sketch.Types.Artboard || layer.type === 'Frame' || layer.type === 'SymbolMaster') {
          layers = layers.concat(getVisibleLayersInOrder(layer));
        }
      }
    });
  }
  return layers;
}

// Function to check if a layer is a stack layout
function isStackLayer(layer) {
  if (!layer || !layer.layers) {
    return false;
  }

  // Check for native layout properties (Smart Layout)
  if (layer.layout && (layer.layout.direction || layer.layout.spacing !== undefined)) {
    return true;
  }

  // Check for Smart Layout via class name
  if (layer.sketchObject && layer.sketchObject.className() === 'MSLayerGroup') {
    var sketchObject = layer.sketchObject;
    if (sketchObject.hasLayout && sketchObject.hasLayout()) {
      return true;
    }
  }

  // TEMP: Debug detection for layers named "Stack" with children
  if (layer.name === 'Stack' && layer.layers && layer.layers.length > 0) {
    return true;
  }

  // Check if children are aligned in a stack-like manner
  if (layer.layers && layer.layers.length >= 2) {
    var children = layer.layers;

    // Check for vertical alignment
    var verticalAlignment = children.every(function (child, index) {
      if (index === 0) return true;
      var prevChild = children[index - 1];
      return Math.abs(child.frame.x - prevChild.frame.x) < 5; // 5px tolerance
    });
    if (verticalAlignment) {
      return true;
    }
  }
  return false;
}

// NEW: Function to detect if a layer is inside a stack layout
function findParentStack(layer) {
  console.log("Looking for parent stack of: ".concat(layer.name, " (").concat(layer.type, ")"));
  var currentLayer = layer;

  // Traverse up the parent chain looking for a stack
  while (currentLayer && currentLayer.parent) {
    var parent = currentLayer.parent;
    console.log("  Checking parent: ".concat(parent.name || 'Unnamed', " (").concat(parent.type, ")"));

    // Skip artboard - we don't want to consider artboard as a stack
    if (parent.type === sketch.Types.Artboard) {
      console.log("  -> Reached artboard, stopping search");
      break;
    }
    if (isStackLayer(parent)) {
      console.log("  -> Found parent stack: ".concat(parent.name));
      return parent;
    }
    currentLayer = parent;
  }
  console.log("  -> No parent stack found");
  return null;
}

// NEW: Function to get siblings of a layer within a stack
function getStackSiblings(layer, parentStack) {
  if (!parentStack || !parentStack.layers) {
    console.log('No parent stack or layers found');
    return [];
  }

  // Get all content children (excluding backgrounds)
  var contentChildren = parentStack.layers.filter(function (child) {
    // Keep text layers and other content
    if (child.type === sketch.Types.Text) return true;
    if (child.type === sketch.Types.Group) return true;
    if (child.type === sketch.Types.Image) return true;
    if (child.type === 'SymbolInstance') return true;

    // For Shape layers, exclude if they seem to be backgrounds
    if (child.type === sketch.Types.Shape) {
      var sizeRatio = child.frame.width * child.frame.height / (parentStack.frame.width * parentStack.frame.height);
      if (sizeRatio > 0.8) {
        return false; // Likely a background
      }
    }
    return true;
  });
  return contentChildren;
}

// NEW: Function to calculate spacing between siblings in a stack
function calculateSiblingSpacing(focusedLayer, parentStack) {
  var siblings = getStackSiblings(focusedLayer, parentStack);
  var stackProps = getStackProperties(parentStack);
  if (!stackProps || siblings.length < 2) {
    return null;
  }

  // Sort siblings by position based on stack direction
  var sortedSiblings = siblings.slice().sort(function (a, b) {
    if (stackProps.direction === 'horizontal') {
      return a.frame.x - b.frame.x;
    } else {
      return a.frame.y - b.frame.y;
    }
  });

  // Find the focused layer's position in the sorted list
  var focusedIndex = sortedSiblings.findIndex(function (sibling) {
    return sibling.name === focusedLayer.name && sibling.type === focusedLayer.type;
  });
  if (focusedIndex === -1) {
    return null;
  }
  var spacing = {};

  // Calculate spacing to previous sibling
  if (focusedIndex > 0) {
    var prevSibling = sortedSiblings[focusedIndex - 1];
    var focusedRect = getAbsoluteRect(focusedLayer, parentStack);
    var prevRect = getAbsoluteRect(prevSibling, parentStack);
    if (stackProps.direction === 'horizontal') {
      spacing.previous = {
        distance: focusedRect.x - (prevRect.x + prevRect.width),
        direction: 'left',
        targetName: prevSibling.name,
        targetLayer: prevSibling
      };
    } else {
      spacing.previous = {
        distance: focusedRect.y - (prevRect.y + prevRect.height),
        direction: 'top',
        targetName: prevSibling.name,
        targetLayer: prevSibling
      };
    }
  }

  // Calculate spacing to next sibling
  if (focusedIndex < sortedSiblings.length - 1) {
    var nextSibling = sortedSiblings[focusedIndex + 1];
    var _focusedRect = getAbsoluteRect(focusedLayer, parentStack);
    var nextRect = getAbsoluteRect(nextSibling, parentStack);
    if (stackProps.direction === 'horizontal') {
      spacing.next = {
        distance: nextRect.x - (_focusedRect.x + _focusedRect.width),
        direction: 'right',
        targetName: nextSibling.name,
        targetLayer: nextSibling
      };
    } else {
      spacing.next = {
        distance: nextRect.y - (_focusedRect.y + _focusedRect.height),
        direction: 'bottom',
        targetName: nextSibling.name,
        targetLayer: nextSibling
      };
    }
  }
  return {
    parentStackName: parentStack.name,
    stackDirection: stackProps.direction,
    totalSiblings: siblings.length,
    focusedIndex: focusedIndex,
    spacing: spacing
  };
}

// NEW: Function to draw sibling spacing measurements
function drawSiblingSpacing(measurementsGroup, focusedLayer, parentStack, originalArtboard) {
  var siblingInfo = calculateSiblingSpacing(focusedLayer, parentStack);
  if (!siblingInfo) {
    return;
  }
  var focusedRect = getAbsoluteRect(focusedLayer, originalArtboard);
  var lineColor = '#00FF00'; // Bright green for sibling spacing
  var lineThickness = 2; // Clean, simple line

  // Draw spacing to previous sibling
  if (siblingInfo.spacing.previous) {
    var spacing = siblingInfo.spacing.previous;
    var targetRect = getAbsoluteRect(spacing.targetLayer, originalArtboard);
    var distance = Math.round(spacing.distance);

    // FIXED: Use absolute coordinates for the duplicated artboard
    // Since the duplicated content is at (0,0) in the new artboard, we use coordinates directly
    var focusedX = focusedRect.x;
    var focusedY = focusedRect.y;
    var targetX = targetRect.x;
    var targetY = targetRect.y;
    var lineX1, lineY1, lineX2, lineY2, textX, textY;
    if (spacing.direction === 'left') {
      // Horizontal spacing (previous sibling to the left) - simple line between elements
      lineX1 = targetX + targetRect.width;
      lineY1 = targetY + targetRect.height / 2;
      lineX2 = focusedX;
      lineY2 = lineY1;
      textX = lineX1 + distance / 2;
      textY = lineY1 - 8;
    } else {
      // Vertical spacing (previous sibling above) - simple line between elements
      lineX1 = targetX + targetRect.width / 2;
      lineY1 = targetY + targetRect.height;
      lineX2 = lineX1;
      lineY2 = focusedY;
      textX = lineX1 + 8; // Small offset to the right
      textY = lineY1 + distance / 2;
    }
    console.log("Drawing line to previous sibling: ".concat(spacing.targetLayer.name));
    console.log("Using coordinates directly: focused(".concat(focusedX, ",").concat(focusedY, "), target(").concat(targetX, ",").concat(targetY, ")"));
    console.log("Line coordinates: (".concat(lineX1, ",").concat(lineY1, ") to (").concat(lineX2, ",").concat(lineY2, "), distance: ").concat(distance, "px"));

    // Draw the spacing line
    if (distance > 0) {
      // For vertical lines, we need proper width/height
      var lineWidth, lineHeight;
      if (lineX1 === lineX2) {
        // Vertical line
        lineWidth = lineThickness;
        lineHeight = Math.abs(lineY2 - lineY1);
      } else {
        // Horizontal line
        lineWidth = Math.abs(lineX2 - lineX1);
        lineHeight = lineThickness;
      }
      var rectX = Math.min(lineX1, lineX2) - (lineX1 === lineX2 ? lineThickness / 2 : 0);
      var rectY = Math.min(lineY1, lineY2) - (lineY1 === lineY2 ? lineThickness / 2 : 0);
      console.log("Creating shape: x=".concat(rectX, ", y=").concat(rectY, ", width=").concat(lineWidth, ", height=").concat(lineHeight));

      // SOLUTION: Create measurement directly at artboard level instead of in a group
      var measurementLine = new sketch.Shape({
        parent: measurementsGroup.parent,
        // Use artboard as parent instead of measurementsGroup
        frame: new sketch.Rectangle(rectX, rectY, lineWidth, lineHeight),
        style: {
          fills: [{
            color: lineColor,
            fillType: sketch.Style.FillType.Color,
            enabled: true
          }],
          borders: []
        }
      });
      console.log("DEBUG: Line created at actual frame: x=".concat(measurementLine.frame.x, ", y=").concat(measurementLine.frame.y, ", width=").concat(measurementLine.frame.width, ", height=").concat(measurementLine.frame.height));

      // Move to front to ensure visibility
      measurementLine.moveToFront();

      // Draw distance label at artboard level
      var distanceLabel1 = new sketch.Text({
        text: "".concat(distance, "px"),
        parent: measurementsGroup.parent,
        // Use artboard as parent instead of measurementsGroup
        frame: new sketch.Rectangle(textX - 15, textY - 6, 30, 12),
        style: {
          fontSize: 10,
          textColor: lineColor,
          alignment: 'center'
        }
      });
      console.log("DEBUG: Distance label created at: x=".concat(distanceLabel1.frame.x, ", y=").concat(distanceLabel1.frame.y, ", width=").concat(distanceLabel1.frame.width, ", height=").concat(distanceLabel1.frame.height));

      // Move to front to ensure visibility
      distanceLabel1.moveToFront();
    }
  }

  // Draw spacing to next sibling
  if (siblingInfo.spacing.next) {
    var _spacing = siblingInfo.spacing.next;
    var _targetRect = getAbsoluteRect(_spacing.targetLayer, originalArtboard);
    var _distance = Math.round(_spacing.distance);

    // FIXED: Use absolute coordinates for the duplicated artboard
    var _focusedX = focusedRect.x;
    var _focusedY = focusedRect.y;
    var _targetX = _targetRect.x;
    var _targetY = _targetRect.y;
    var _lineX, _lineY, _lineX2, _lineY2, _textX, _textY;
    if (_spacing.direction === 'right') {
      // Horizontal spacing (next sibling to the right) - simple line between elements
      _lineX = _focusedX + focusedRect.width;
      _lineY = _focusedY + focusedRect.height / 2;
      _lineX2 = _targetX;
      _lineY2 = _lineY;
      _textX = _lineX + _distance / 2;
      _textY = _lineY - 8;
    } else {
      // Vertical spacing (next sibling below) - simple line between elements
      _lineX = _focusedX + focusedRect.width / 2;
      _lineY = _focusedY + focusedRect.height;
      _lineX2 = _lineX;
      _lineY2 = _targetY;
      _textX = _lineX + 8; // Small offset to the right
      _textY = _lineY + _distance / 2;
    }

    // Draw the spacing line
    if (_distance > 0) {
      // For vertical lines, we need proper width/height
      var _lineWidth, _lineHeight;
      if (_lineX === _lineX2) {
        // Vertical line
        _lineWidth = lineThickness;
        _lineHeight = Math.abs(_lineY2 - _lineY);
      } else {
        // Horizontal line
        _lineWidth = Math.abs(_lineX2 - _lineX);
        _lineHeight = lineThickness;
      }

      // SOLUTION: Create measurement directly at artboard level instead of in a group
      var measurementLine2 = new sketch.Shape({
        parent: measurementsGroup.parent,
        // Use artboard as parent instead of measurementsGroup
        frame: new sketch.Rectangle(Math.min(_lineX, _lineX2) - (_lineX === _lineX2 ? lineThickness / 2 : 0), Math.min(_lineY, _lineY2) - (_lineY === _lineY2 ? lineThickness / 2 : 0), _lineWidth, _lineHeight),
        style: {
          fills: [{
            color: lineColor,
            fillType: sketch.Style.FillType.Color,
            enabled: true
          }],
          borders: []
        }
      });

      // Move to front to ensure visibility
      measurementLine2.moveToFront();

      // Draw distance label at artboard level
      var distanceLabel2 = new sketch.Text({
        text: "".concat(_distance, "px"),
        parent: measurementsGroup.parent,
        // Use artboard as parent instead of measurementsGroup
        frame: new sketch.Rectangle(_textX - 15, _textY - 6, 30, 12),
        style: {
          fontSize: 10,
          textColor: lineColor,
          alignment: 'center'
        }
      });

      // Move to front to ensure visibility
      distanceLabel2.moveToFront();
    }
  }
  return siblingInfo;
}

// Function to get tight content bounds for a layer
function getTightContentBounds(layer) {
  // For text layers, calculate actual text bounds
  if (layer.type === sketch.Types.Text) {
    // Use the layer's frame as-is for text - Sketch should handle text bounds correctly
    return {
      x: layer.frame.x,
      y: layer.frame.y,
      width: layer.frame.width,
      height: layer.frame.height
    };
  }

  // For other layers, use frame bounds
  return {
    x: layer.frame.x,
    y: layer.frame.y,
    width: layer.frame.width,
    height: layer.frame.height
  };
}

// Function to get stack properties including calculated padding
function getStackProperties(layer) {
  if (!isStackLayer(layer)) {
    return null;
  }
  var stackFrame = layer.frame;

  // Get all immediate children, excluding background layers
  var allChildren = layer.layers || [];

  // Filter out background layers (typically Shape layers at the bottom)
  var contentChildren = allChildren.filter(function (child) {
    // Keep text layers and other content
    if (child.type === sketch.Types.Text) return true;
    if (child.type === sketch.Types.Group) return true;
    if (child.type === sketch.Types.Image) return true;
    if (child.type === 'SymbolInstance') return true;

    // For Shape layers, exclude if they seem to be backgrounds
    if (child.type === sketch.Types.Shape) {
      // If it's roughly the same size as the parent, it's likely a background
      var sizeRatio = child.frame.width * child.frame.height / (stackFrame.width * stackFrame.height);
      if (sizeRatio > 0.8) {
        return false; // Likely a background
      }
    }
    return true;
  });
  if (contentChildren.length === 0) {
    return null;
  }

  // Calculate content bounding box using tight bounds
  var contentMinX = Infinity;
  var contentMinY = Infinity;
  var contentMaxX = -Infinity;
  var contentMaxY = -Infinity;
  contentChildren.forEach(function (child) {
    var tightBounds = getTightContentBounds(child);

    // Convert to absolute coordinates within the stack
    var childX = tightBounds.x;
    var childY = tightBounds.y;
    contentMinX = Math.min(contentMinX, childX);
    contentMinY = Math.min(contentMinY, childY);
    contentMaxX = Math.max(contentMaxX, childX + tightBounds.width);
    contentMaxY = Math.max(contentMaxY, childY + tightBounds.height);
  });
  var contentWidth = contentMaxX - contentMinX;
  var contentHeight = contentMaxY - contentMinY;
  var containerWidth = stackFrame.width;
  var containerHeight = stackFrame.height;

  // Detect if this is a "Fit" mode container (much wider than content)
  var effectiveWidth = containerWidth;

  // If container is much wider than content, assume "Fit" mode
  if (containerWidth > contentWidth + 100) {
    effectiveWidth = contentWidth + contentMinX * 2; // content width + padding on both sides
  }

  // Calculate padding
  var topPadding = contentMinY;
  var leftPadding = contentMinX;
  var bottomPadding = containerHeight - contentMaxY;
  var rightPadding = effectiveWidth - contentMaxX;

  // Snap to common padding values
  var snapToPadding = function snapToPadding(value) {
    var commonPaddings = [0, 4, 8, 12, 16, 20, 24, 32, 40, 48, 64];
    return commonPaddings.find(function (p) {
      return Math.abs(value - p) <= 2;
    }) || Math.round(value);
  };
  var snappedTop = snapToPadding(topPadding);
  var snappedLeft = snapToPadding(leftPadding);
  var snappedBottom = snapToPadding(bottomPadding);
  var snappedRight = snapToPadding(rightPadding);

  // Determine direction based on layout
  var direction = 'vertical';
  if (contentChildren.length >= 2) {
    var firstChild = contentChildren[0];
    var secondChild = contentChildren[1];

    // If children are more horizontally aligned, it's horizontal
    if (Math.abs(firstChild.frame.y - secondChild.frame.y) < Math.abs(firstChild.frame.x - secondChild.frame.x)) {
      direction = 'horizontal';
    }
  }
  var properties = {
    direction: direction,
    padding: {
      top: snappedTop,
      left: snappedLeft,
      bottom: snappedBottom,
      right: snappedRight
    },
    spacing: 8 // Default spacing
  };
  return properties;
}

// Calculate spacing between layers
function calculateSpacing(focusedLayer, otherLayer, originalArtboard) {
  var focusedRect = getAbsoluteRect(focusedLayer, originalArtboard);
  var otherRect = getAbsoluteRect(otherLayer, originalArtboard);
  var fRect = {
    x: focusedRect.x,
    y: focusedRect.y,
    width: focusedRect.width,
    height: focusedRect.height
  };
  var oRect = {
    x: otherRect.x,
    y: otherRect.y,
    width: otherRect.width,
    height: otherRect.height
  };

  // Calculate minimum distances
  var distances = [];

  // Top
  if (oRect.y + oRect.height <= fRect.y) {
    distances.push({
      direction: 'top',
      distance: fRect.y - (oRect.y + oRect.height),
      target: 'layer',
      targetName: otherLayer.name,
      targetPosition: {
        x: oRect.x,
        y: oRect.y
      },
      targetSize: {
        width: oRect.width,
        height: oRect.height
      }
    });
  }

  // Bottom
  if (oRect.y >= fRect.y + fRect.height) {
    distances.push({
      direction: 'bottom',
      distance: oRect.y - (fRect.y + fRect.height),
      target: 'layer',
      targetName: otherLayer.name,
      targetPosition: {
        x: oRect.x,
        y: oRect.y
      },
      targetSize: {
        width: oRect.width,
        height: oRect.height
      }
    });
  }

  // Left
  if (oRect.x + oRect.width <= fRect.x) {
    distances.push({
      direction: 'left',
      distance: fRect.x - (oRect.x + oRect.width),
      target: 'layer',
      targetName: otherLayer.name,
      targetPosition: {
        x: oRect.x,
        y: oRect.y
      },
      targetSize: {
        width: oRect.width,
        height: oRect.height
      }
    });
  }

  // Right
  if (oRect.x >= fRect.x + fRect.width) {
    distances.push({
      direction: 'right',
      distance: oRect.x - (fRect.x + fRect.width),
      target: 'layer',
      targetName: otherLayer.name,
      targetPosition: {
        x: oRect.x,
        y: oRect.y
      },
      targetSize: {
        width: oRect.width,
        height: oRect.height
      }
    });
  }
  return distances;
}

// Helper function to draw a spacing line with proper styling
function drawSpacingLine(measurementsGroup, direction, distance, targetName, color) {
  // Colors for different target types
  var lineColor = targetName === 'artboard edge' ? '#9966FF' : '#FF0000'; // Purple for artboard, red for layers
  var lineThickness = 2;

  // This is a placeholder - the actual visual drawing will be implemented in drawDirectionalSpacing
  // where we have access to the coordinates
}

// Function to draw directional spacing measurements
function drawDirectionalSpacing(measurementsGroup, focusedLayer, otherLayers, originalArtboard) {
  var focusedRect = getAbsoluteRect(focusedLayer, originalArtboard);
  var artboardRect = {
    x: 0,
    y: 0,
    width: originalArtboard.frame.width,
    height: originalArtboard.frame.height
  };

  // Find closest layers/edges in each direction
  var directions = {
    top: {
      distance: focusedRect.y,
      target: 'artboard',
      targetName: 'artboard edge'
    },
    bottom: {
      distance: artboardRect.height - (focusedRect.y + focusedRect.height),
      target: 'artboard',
      targetName: 'artboard edge'
    },
    left: {
      distance: focusedRect.x,
      target: 'artboard',
      targetName: 'artboard edge'
    },
    right: {
      distance: artboardRect.width - (focusedRect.x + focusedRect.width),
      target: 'artboard',
      targetName: 'artboard edge'
    }
  };

  // Check for closer layers
  otherLayers.forEach(function (layer) {
    if (layer !== focusedLayer) {
      var spacings = calculateSpacing(focusedLayer, layer, originalArtboard);
      spacings.forEach(function (spacing) {
        if (!directions[spacing.direction] || spacing.distance < directions[spacing.direction].distance) {
          directions[spacing.direction] = spacing;
        }
      });
    }
  });

  // Draw visual spacing lines for each direction
  Object.keys(directions).forEach(function (direction) {
    var spacing = directions[direction];
    if (spacing && spacing.distance >= 0) {
      drawSpacingLine(measurementsGroup, direction, Math.round(spacing.distance), spacing.targetName, '#FF0000');

      // Draw the actual visual spacing line
      var lineColor = spacing.target === 'artboard' ? '#9966FF' : '#FF0000'; // Purple for artboard, red for layers
      var lineThickness = 2;
      var distance = Math.round(spacing.distance);

      // Calculate line coordinates based on direction
      var lineX1, lineY1, lineX2, lineY2, textX, textY;
      switch (direction) {
        case 'top':
          lineX1 = focusedRect.x + focusedRect.width / 2;
          lineY1 = focusedRect.y;
          lineX2 = lineX1;
          lineY2 = focusedRect.y - distance;
          textX = lineX1 + 10;
          textY = lineY1 - distance / 2;
          break;
        case 'bottom':
          lineX1 = focusedRect.x + focusedRect.width / 2;
          lineY1 = focusedRect.y + focusedRect.height;
          lineX2 = lineX1;
          lineY2 = lineY1 + distance;
          textX = lineX1 + 10;
          textY = lineY1 + distance / 2;
          break;
        case 'left':
          lineX1 = focusedRect.x;
          lineY1 = focusedRect.y + focusedRect.height / 2;
          lineX2 = focusedRect.x - distance;
          lineY2 = lineY1;
          textX = lineX1 - distance / 2;
          textY = lineY1 - 10;
          break;
        case 'right':
          lineX1 = focusedRect.x + focusedRect.width;
          lineY1 = focusedRect.y + focusedRect.height / 2;
          lineX2 = lineX1 + distance;
          lineY2 = lineY1;
          textX = lineX1 + distance / 2;
          textY = lineY1 - 10;
          break;
      }

      // Draw the spacing line
      if (distance > 0) {
        new sketch.Shape({
          parent: measurementsGroup,
          frame: new sketch.Rectangle(Math.min(lineX1, lineX2) - lineThickness / 2, Math.min(lineY1, lineY2) - lineThickness / 2, Math.abs(lineX2 - lineX1) + lineThickness, Math.abs(lineY2 - lineY1) + lineThickness),
          style: {
            fills: [{
              color: lineColor,
              fillType: sketch.Style.FillType.Color,
              enabled: true
            }],
            borders: []
          }
        });

        // Draw distance label
        new sketch.Text({
          text: "".concat(distance, "px"),
          parent: measurementsGroup,
          frame: new sketch.Rectangle(textX - 20, textY - 8, 40, 16),
          style: {
            fontSize: 11,
            textColor: lineColor,
            alignment: 'center'
          }
        });
      }
    }
  });
  return directions;
}

// Generate focused layer specs
function generateFocusedLayerSpecs(focusedLayer, allLayers, originalArtboard) {
  var focusedRect = getAbsoluteRect(focusedLayer, originalArtboard);
  var artboardRect = {
    x: 0,
    y: 0,
    width: originalArtboard.frame.width,
    height: originalArtboard.frame.height
  };

  // Calculate directional spacing
  var directionalSpacing = {};
  var otherLayers = allLayers.filter(function (layer) {
    return layer !== focusedLayer;
  });

  // Find closest elements in each direction
  var directions = ['top', 'bottom', 'left', 'right'];
  directions.forEach(function (direction) {
    var closest = null;
    var minDistance = Infinity;

    // Check artboard edges
    var edgeDistance;
    switch (direction) {
      case 'top':
        edgeDistance = focusedRect.y;
        break;
      case 'bottom':
        edgeDistance = artboardRect.height - (focusedRect.y + focusedRect.height);
        break;
      case 'left':
        edgeDistance = focusedRect.x;
        break;
      case 'right':
        edgeDistance = artboardRect.width - (focusedRect.x + focusedRect.width);
        break;
    }
    if (edgeDistance < minDistance) {
      minDistance = edgeDistance;
      closest = {
        target: 'artboard',
        targetName: 'artboard edge',
        distance: Math.round(edgeDistance)
      };
    }

    // Check other layers
    otherLayers.forEach(function (layer) {
      var spacings = calculateSpacing(focusedLayer, layer, originalArtboard);
      var directionSpacing = spacings.find(function (s) {
        return s.direction === direction;
      });
      if (directionSpacing && directionSpacing.distance < minDistance) {
        minDistance = directionSpacing.distance;
        closest = {
          target: 'layer',
          targetName: directionSpacing.targetName,
          distance: Math.round(directionSpacing.distance),
          targetPosition: directionSpacing.targetPosition,
          targetSize: directionSpacing.targetSize
        };
      }
    });
    directionalSpacing[direction] = closest;
  });
  var specs = {
    artboard: {
      name: originalArtboard.name,
      width: originalArtboard.frame.width,
      height: originalArtboard.frame.height
    },
    focusedLayer: {
      name: focusedLayer.name,
      type: focusedLayer.type,
      position: {
        x: focusedRect.x,
        y: focusedRect.y
      },
      size: {
        width: focusedRect.width,
        height: focusedRect.height
      },
      directionalSpacing: directionalSpacing
    }
  };
  return specs;
}

// Draw Stack specifications panel with beautiful design
function drawStackSpecificationsPanel(artboard, stackLayers, originalArtboard) {
  var debugMode = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
  var focusedLayer = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;
  var siblingInfo = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : null;
  var panelWidth = 360;
  var panelHeight = 320;
  var panelX = originalArtboard.frame.width + 60;
  var panelY = 50;

  // Modern gradient background
  new sketch.Shape({
    parent: artboard,
    frame: new sketch.Rectangle(panelX, panelY, panelWidth, panelHeight),
    style: {
      fills: [{
        color: '#FFFFFF',
        fillType: sketch.Style.FillType.Color,
        enabled: true
      }],
      borders: [{
        color: '#E8E8E8',
        thickness: 1,
        enabled: true
      }],
      shadows: [{
        color: '#00000015',
        x: 0,
        y: 8,
        blur: 24,
        spread: 0,
        enabled: true
      }]
    }
  });

  // Header gradient bar
  new sketch.Shape({
    parent: artboard,
    frame: new sketch.Rectangle(panelX, panelY, panelWidth, 4),
    style: {
      fills: [{
        color: '#007AFF',
        fillType: sketch.Style.FillType.Color,
        enabled: true
      }],
      borders: []
    }
  });

  // Panel title with modern typography
  var title = focusedLayer ? 'Stack Layout Analysis' : 'Stack Layout Properties';
  var subtitle = focusedLayer ? "\"".concat(focusedLayer.name, "\" \u2022 Stack Layout") : "".concat(stackLayers.length, " stack layout").concat(stackLayers.length !== 1 ? 's' : '', " detected");
  new sketch.Text({
    text: title,
    parent: artboard,
    frame: new sketch.Rectangle(panelX + 24, panelY + 32, panelWidth - 48, 28),
    style: {
      fontSize: 20,
      fontWeight: 600,
      textColor: '#1D1D1F',
      alignment: 'left'
    }
  });
  new sketch.Text({
    text: subtitle,
    parent: artboard,
    frame: new sketch.Rectangle(panelX + 24, panelY + 64, panelWidth - 48, 18),
    style: {
      fontSize: 13,
      textColor: '#86868B',
      alignment: 'left'
    }
  });

  // Stack entries with modern card design
  var entryY = panelY + 110;
  var layersToShow = focusedLayer ? [focusedLayer] : stackLayers;
  layersToShow.forEach(function (stack, index) {
    var stackProps = getStackProperties(stack);
    if (stackProps) {
      // Stack card background
      new sketch.Shape({
        parent: artboard,
        frame: new sketch.Rectangle(panelX + 24, entryY, panelWidth - 48, 180),
        style: {
          fills: [{
            color: '#F8F9FA',
            fillType: sketch.Style.FillType.Color,
            enabled: true
          }],
          borders: [{
            color: '#E9ECEF',
            thickness: 1,
            enabled: true
          }]
        }
      });

      // Stack icon and name
      new sketch.Text({
        text: '📦',
        parent: artboard,
        frame: new sketch.Rectangle(panelX + 40, entryY + 20, 20, 20),
        style: {
          fontSize: 16,
          alignment: 'left'
        }
      });
      new sketch.Text({
        text: stack.name,
        parent: artboard,
        frame: new sketch.Rectangle(panelX + 68, entryY + 20, panelWidth - 92, 20),
        style: {
          fontSize: 16,
          fontWeight: 500,
          textColor: '#1D1D1F',
          alignment: 'left'
        }
      });

      // Properties section
      var propY = entryY + 56;

      // Padding section header
      new sketch.Text({
        text: '📐 Padding',
        parent: artboard,
        frame: new sketch.Rectangle(panelX + 40, propY, 120, 16),
        style: {
          fontSize: 12,
          fontWeight: 500,
          textColor: '#495057',
          alignment: 'left'
        }
      });
      propY += 24;

      // Padding grid (2x2)
      var paddingProps = [{
        label: 'Top',
        value: "".concat(stackProps.padding.top, "px"),
        x: 0,
        y: 0
      }, {
        label: 'Right',
        value: "".concat(stackProps.padding.right, "px"),
        x: 1,
        y: 0
      }, {
        label: 'Bottom',
        value: "".concat(stackProps.padding.bottom, "px"),
        x: 0,
        y: 1
      }, {
        label: 'Left',
        value: "".concat(stackProps.padding.left, "px"),
        x: 1,
        y: 1
      }];
      paddingProps.forEach(function (prop) {
        var x = panelX + 40 + prop.x * 120;
        var y = propY + prop.y * 28;

        // Padding label
        new sketch.Text({
          text: prop.label,
          parent: artboard,
          frame: new sketch.Rectangle(x, y, 60, 14),
          style: {
            fontSize: 11,
            textColor: '#6C757D',
            alignment: 'left'
          }
        });

        // Padding value with accent color
        new sketch.Text({
          text: prop.value,
          parent: artboard,
          frame: new sketch.Rectangle(x + 60, y, 50, 14),
          style: {
            fontSize: 11,
            fontWeight: 500,
            textColor: '#007AFF',
            alignment: 'left'
          }
        });
      });

      // Add sibling spacing information if available
      if (siblingInfo && focusedLayer) {
        propY += 80; // Space after padding grid

        // Sibling spacing section header
        new sketch.Text({
          text: '🔗 Sibling Spacing',
          parent: artboard,
          frame: new sketch.Rectangle(panelX + 40, propY, 150, 16),
          style: {
            fontSize: 12,
            fontWeight: 500,
            textColor: '#495057',
            alignment: 'left'
          }
        });
        propY += 24;

        // Stack info
        new sketch.Text({
          text: "In \"".concat(siblingInfo.parentStackName, "\" (").concat(siblingInfo.stackDirection, ")"),
          parent: artboard,
          frame: new sketch.Rectangle(panelX + 40, propY, panelWidth - 80, 14),
          style: {
            fontSize: 11,
            textColor: '#6C757D',
            alignment: 'left'
          }
        });
        propY += 20;

        // Position info
        new sketch.Text({
          text: "Position: ".concat(siblingInfo.focusedIndex + 1, " of ").concat(siblingInfo.totalSiblings),
          parent: artboard,
          frame: new sketch.Rectangle(panelX + 40, propY, panelWidth - 80, 14),
          style: {
            fontSize: 11,
            textColor: '#6C757D',
            alignment: 'left'
          }
        });
        propY += 24;

        // Spacing to previous sibling
        if (siblingInfo.spacing.previous) {
          new sketch.Text({
            text: "\u2190 ".concat(siblingInfo.spacing.previous.targetName),
            parent: artboard,
            frame: new sketch.Rectangle(panelX + 40, propY, 120, 14),
            style: {
              fontSize: 11,
              textColor: '#6C757D',
              alignment: 'left'
            }
          });
          new sketch.Text({
            text: "".concat(siblingInfo.spacing.previous.distance, "px"),
            parent: artboard,
            frame: new sketch.Rectangle(panelX + 160, propY, 50, 14),
            style: {
              fontSize: 11,
              fontWeight: 500,
              textColor: '#00AA00',
              alignment: 'left'
            }
          });
          propY += 20;
        }

        // Spacing to next sibling
        if (siblingInfo.spacing.next) {
          new sketch.Text({
            text: "\u2192 ".concat(siblingInfo.spacing.next.targetName),
            parent: artboard,
            frame: new sketch.Rectangle(panelX + 40, propY, 120, 14),
            style: {
              fontSize: 11,
              textColor: '#6C757D',
              alignment: 'left'
            }
          });
          new sketch.Text({
            text: "".concat(siblingInfo.spacing.next.distance, "px"),
            parent: artboard,
            frame: new sketch.Rectangle(panelX + 160, propY, 50, 14),
            style: {
              fontSize: 11,
              fontWeight: 500,
              textColor: '#00AA00',
              alignment: 'left'
            }
          });
          propY += 20;
        }

        // Note about green lines
        new sketch.Text({
          text: '📍 Green lines show sibling spacing',
          parent: artboard,
          frame: new sketch.Rectangle(panelX + 40, propY, panelWidth - 80, 14),
          style: {
            fontSize: 10,
            textColor: '#00AA00',
            alignment: 'left'
          }
        });
      }
      entryY += 200; // Space between entries
    }
  });
}

// Main function to create layout spacing specs
function createLayoutSpacingSpecs(originalArtboard) {
  var focusedLayer = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  var allLayers = getVisibleLayersInOrder(originalArtboard);

  // Detect stack layers
  var stackLayers = [];
  if (focusedLayer) {
    if (isStackLayer(focusedLayer)) {
      stackLayers.push(focusedLayer);
    }
  } else {
    // Check all layers
    allLayers.forEach(function (layer) {
      if (isStackLayer(layer)) {
        stackLayers.push(layer);
      }
    });
  }

  // Create spacing artboard with proper height to fit the panel
  var panelWidth = 360;
  var panelHeight = 320;
  var panelY = 50;
  var bottomMargin = 100; // Extra space at bottom
  var panelX = originalArtboard.frame.width + 60;
  var rightMargin = 40; // Extra space after panel
  var minArtboardHeight = Math.max(originalArtboard.frame.height, panelY + panelHeight + bottomMargin);

  // Calculate artboard width to accommodate the panel properly
  var artboardWidth = panelX + panelWidth + rightMargin;
  var spacingArtboard = new sketch.Artboard({
    name: "Spacing: ".concat(originalArtboard.name),
    parent: originalArtboard.parent,
    frame: new sketch.Rectangle(originalArtboard.frame.x + originalArtboard.frame.width + 120, originalArtboard.frame.y, artboardWidth, minArtboardHeight)
  });

  // Add light grey background for better contrast
  new sketch.Shape({
    parent: spacingArtboard,
    frame: new sketch.Rectangle(0, 0, spacingArtboard.frame.width, spacingArtboard.frame.height),
    style: {
      fills: [{
        color: '#F8F9FA',
        fillType: sketch.Style.FillType.Color,
        enabled: true
      }],
      borders: []
    }
  });

  // Duplicate original artboard content
  var duplicatedContent = originalArtboard.duplicate();
  duplicatedContent.parent = spacingArtboard;
  duplicatedContent.frame.x = 0;
  duplicatedContent.frame.y = 0;
  duplicatedContent.selected = false;

  // Initialize siblingInfo for use in panel
  var siblingInfo = null;

  // Draw spacing measurements if focused layer is provided
  if (focusedLayer) {
    // Create measurements group at the top level, completely separate from any layout influence
    var measurementsGroup = new sketch.Group({
      name: 'Spacing Measurements',
      parent: spacingArtboard
    });

    // Move the measurements group to the front and ensure it's not affected by any layout
    measurementsGroup.moveToFront();
    measurementsGroup.locked = false;

    // CRITICAL: Apply absolute positioning constraints to the measurements group itself
    // This prevents Stack Layout from repositioning the entire group

    // SOLUTION: Set "ignore stack layout" programmatically 
    if (measurementsGroup.sketchObject) {
      // Try different possible property names for "ignore stack layout"
      if (measurementsGroup.sketchObject.setIsIgnoredForStackLayout) {
        measurementsGroup.sketchObject.setIsIgnoredForStackLayout(true);
        console.log("DEBUG: Set isIgnoredForStackLayout to true");
      } else if (measurementsGroup.sketchObject.setIgnoreStackLayout) {
        measurementsGroup.sketchObject.setIgnoreStackLayout(true);
        console.log("DEBUG: Set ignoreStackLayout to true");
      } else if (measurementsGroup.sketchObject.setIsExcludedFromLayout) {
        measurementsGroup.sketchObject.setIsExcludedFromLayout(true);
        console.log("DEBUG: Set isExcludedFromLayout to true");
      } else if (measurementsGroup.sketchObject.setExcludeFromLayout) {
        measurementsGroup.sketchObject.setExcludeFromLayout(true);
        console.log("DEBUG: Set excludeFromLayout to true");
      } else {
        console.log("DEBUG: Could not find ignore stack layout property");
      }
    }
    if (measurementsGroup.sketchObject && measurementsGroup.sketchObject.setConstrainProportions) {
      measurementsGroup.sketchObject.setConstrainProportions(false);
    }
    if (measurementsGroup.sketchObject && measurementsGroup.sketchObject.hasFixedLeft) {
      measurementsGroup.sketchObject.setHasFixedLeft(true);
      measurementsGroup.sketchObject.setHasFixedTop(true);
      measurementsGroup.sketchObject.setHasFixedRight(false);
      measurementsGroup.sketchObject.setHasFixedBottom(false);
      measurementsGroup.sketchObject.setHasFixedWidth(true);
      measurementsGroup.sketchObject.setHasFixedHeight(true);
    }

    // Add cyan highlight for the focused layer
    var focusedRect = getAbsoluteRect(focusedLayer, originalArtboard);
    // Use coordinates directly since duplicated content is at (0,0) in new artboard
    var highlightX = focusedRect.x;
    var highlightY = focusedRect.y;
    var highlightShape = new sketch.Shape({
      parent: spacingArtboard,
      // Use artboard as parent instead of measurementsGroup
      frame: new sketch.Rectangle(highlightX - 2, highlightY - 2, focusedRect.width + 4, focusedRect.height + 4),
      style: {
        fills: [{
          color: '#00D4FF66',
          fillType: sketch.Style.FillType.Color,
          enabled: true
        }],
        // Cyan with opacity
        borders: [{
          color: '#00D4FF',
          thickness: 2,
          enabled: true
        }]
      }
    });

    // Move to front to ensure visibility
    highlightShape.moveToFront();

    // Find parent stack for sibling spacing analysis
    var parentStack = findParentStack(focusedLayer);
    console.log("=== SIBLING SPACING DEBUG ===");
    console.log("Focused layer: ".concat(focusedLayer.name, " (").concat(focusedLayer.type, ")"));
    console.log("Parent stack found: ".concat(parentStack ? parentStack.name : 'None'));
    if (parentStack) {
      console.log("Parent stack type: ".concat(parentStack.type));
      console.log("Parent stack children count: ".concat(parentStack.layers ? parentStack.layers.length : 0));

      // Draw sibling spacing measurements (green lines)
      siblingInfo = drawSiblingSpacing(measurementsGroup, focusedLayer, parentStack, originalArtboard);
      console.log("Sibling info calculated:", siblingInfo ? 'Yes' : 'No');

      // Add the parent stack to our stack layers list if not already there
      if (!stackLayers.includes(parentStack)) {
        stackLayers.push(parentStack);
      }
    } else {
      console.log("No parent stack - checking if focused layer itself is a stack");
      if (isStackLayer(focusedLayer)) {
        console.log("Focused layer IS a stack - using directional spacing");
      }
      // Draw regular directional spacing measurements (red/purple lines)
      var directionalSpacing = drawDirectionalSpacing(measurementsGroup, focusedLayer, allLayers, originalArtboard);
    }

    // Generate developer specs
    var specs = generateFocusedLayerSpecs(focusedLayer, allLayers, originalArtboard);
  }

  // Draw specifications panel  
  var debugMode = true; // Force panel to show for testing
  var showPanel = stackLayers.length > 0 || debugMode;
  if (showPanel) {
    drawStackSpecificationsPanel(spacingArtboard, stackLayers, originalArtboard, debugMode, focusedLayer, siblingInfo);
  }
  return spacingArtboard;
}
module.exports = {
  createLayoutSpacingSpecs: createLayoutSpacingSpecs,
  getVisibleLayersInOrder: getVisibleLayersInOrder,
  isStackLayer: isStackLayer,
  getStackProperties: getStackProperties,
  findParentStack: findParentStack,
  getStackSiblings: getStackSiblings,
  calculateSiblingSpacing: calculateSiblingSpacing,
  drawSiblingSpacing: drawSiblingSpacing
};

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__layout-spacing-command.js.map